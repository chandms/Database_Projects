INSERT INTO continent ( encompasses_continent, continent_area ) VALUES ( 'Australia/Oceania', 9000000 ) ;
INSERT INTO continent ( encompasses_continent, continent_area ) VALUES ( 'Asia', 44614500 ) ;
INSERT INTO continent ( encompasses_continent, continent_area ) VALUES ( 'North America', 24709000 ) ;
INSERT INTO continent ( encompasses_continent, continent_area ) VALUES ( 'Europe', 10523000 ) ;
INSERT INTO continent ( encompasses_continent, continent_area ) VALUES ( 'Africa', 30221500 ) ;
INSERT INTO continent ( encompasses_continent, continent_area ) VALUES ( 'South America', 17840000 ) ;
